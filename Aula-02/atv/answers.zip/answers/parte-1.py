def informacoes_pessoais():
    
    nome = 'Sam'
    idade = 140
    cidade = 'Imperatriz'

    print(f'Olá {nome}, voce tem {idade} e estuda em {cidade} - Ma')

informacoes_pessoais()
